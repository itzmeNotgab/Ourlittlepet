# Security, release signing and Play Protect

## GitHub Secrets
| Secret | Needed for |
|---|---|
| GOOGLE_SERVICES_JSON (or GOOGLE_SERVICES_JSON_B64) | Firebase in the APK (your real file from the Firebase console) |
| FIREBASE_SERVICE_ACCOUNT | Deploy Firebase workflow only |
| ANDROID_KEYSTORE_B64 | Release APK (base64 of your release keystore) |
| ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD | Release APK |

The release APK step runs only when ANDROID_KEYSTORE_B64 exists. Never commit keystores or service-account files (.gitignore blocks them).

## Create a release keystore (once, in a Codespace terminal)
    keytool -genkeypair -v -keystore release.keystore -alias olp -keyalg RSA -keysize 2048 -validity 10000
    base64 -w0 release.keystore
Paste the base64 output into ANDROID_KEYSTORE_B64, then keep release.keystore backed up privately. Add the release SHA-1 (`keytool -list -v -keystore release.keystore`) to Firebase and re-download google-services.json.

## What was hardened (applied by scripts/bootstrap-android.js)
- allowBackup=false, cleartext traffic disabled in the main manifest.
- Release builds use the release key from environment variables, never the debug key.
- Only INTERNET and POST_NOTIFICATIONS plus library-required permissions.

## Not verified / still to review
Nothing in this repair was built or run (no network in the repair sandbox). Check the merged manifest after the first CI build for exported components, and consider enabling R8/ProGuard (needs testing with Firebase). Firestore/Storage/Database rules were not changed.

## Play Protect
A manually installed APK can still show an "unknown app" warning. Signing with one consistent release key, minimal permissions and no debug flags improves trust but does not remove it; do not try to bypass Play Protect. Publishing through Google Play (internal testing) is the reliable fix.
